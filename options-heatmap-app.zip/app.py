from flask import Flask, render_template, request
import yfinance as yf
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import seaborn as sns
import matplotlib.pyplot as plt
import os

app = Flask(__name__)

def fetch_options_data(ticker, expiration):
    ticker_obj = yf.Ticker(ticker)
    opt = ticker_obj.option_chain(expiration)
    calls = opt.calls.assign(type='Call')
    puts = opt.puts.assign(type='Put')
    df = pd.concat([calls, puts])
    return df

def get_expirations_within_90dte(ticker):
    ticker_obj = yf.Ticker(ticker)
    expirations = ticker_obj.options
    today = datetime.today()
    return [exp for exp in expirations if datetime.strptime(exp, '%Y-%m-%d') <= today + timedelta(days=90)]

def filter_strikes(df, current_price, limit=50):
    strikes = sorted(df.index)
    closest = min(strikes, key=lambda x: abs(x - current_price))
    idx = strikes.index(closest)
    return df.iloc[max(0, idx - limit):min(len(strikes), idx + limit)]

@app.route("/", methods=["GET", "POST"])
def index():
    chart_path = None
    ticker = ""
    error = None
    if request.method == "POST":
        ticker = request.form["ticker"].upper()
        try:
            ticker_obj = yf.Ticker(ticker)
            current_price = ticker_obj.history(period='1d')['Close'].iloc[0]

            expirations = get_expirations_within_90dte(ticker)
            all_data = pd.DataFrame()

            for exp in expirations:
                df_raw = fetch_options_data(ticker, exp)
                df_raw['expiration'] = exp
                all_data = pd.concat([all_data, df_raw])

            calls = all_data[all_data['type'] == 'Call'].pivot_table(index='strike', columns='expiration', values='openInterest', aggfunc='sum', fill_value=0)
            puts = all_data[all_data['type'] == 'Put'].pivot_table(index='strike', columns='expiration', values='openInterest', aggfunc='sum', fill_value=0)

            all_strikes = sorted(set(calls.index).union(set(puts.index)))
            calls = calls.reindex(all_strikes, fill_value=0)
            puts = puts.reindex(all_strikes, fill_value=0)

            combined = calls - puts
            combined = filter_strikes(combined, current_price)

            fig, ax = plt.subplots(figsize=(20, 14))
            cmap = sns.diverging_palette(10, 133, s=90, l=50, as_cmap=True)

            sns.heatmap(combined, annot=combined, fmt='.0f', cmap=cmap, center=0,
                        linewidths=0.3, linecolor='white', cbar_kws={"shrink": .5}, annot_kws={"size": 8}, ax=ax)

            y_pos = np.abs(combined.index - current_price).argmin()
            ax.axhline(y=y_pos, color='red', linestyle='--', lw=2)
            ax.text(0.5, y_pos, f'Current Price: {current_price:.2f}', color='red', fontsize=12,
                    va='bottom', ha='left', backgroundcolor='white')

            ax.set_title(f"Net Open Interest (Calls - Puts) for {ticker}", fontsize=16, pad=15)
            ax.set_xlabel("Expiration Date")
            ax.set_ylabel("Strike Price")
            plt.xticks(rotation=45)
            plt.tight_layout()

            chart_path = os.path.join("static", "heatmap.png")
            plt.savefig(chart_path)
            plt.close()

        except Exception as e:
            error = str(e)

    return render_template("index.html", chart=chart_path, ticker=ticker, error=error)

if __name__ == "__main__":
    app.run(debug=True)